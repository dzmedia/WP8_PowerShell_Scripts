﻿<#
               a

.SYNOPSIS
BuildMDILAPPXP.ps1 optimizes APPX packages allowing them to launch without JIT compilation.

.DESCRIPTION
    This script performs the series of actions needed to optimize an APPX Package to avoid JfaIT compilation during launch. 
    
    All parameters are optional. 
    By default, expand and compile working folders are  set to "C:\temp\APPXInput" and "C:\temp\APPXInput" respectively.
    For Appx, packages are expanded to the $APPXInput folder, compiled to the $APPXOutput folder. 
    If -certpath and -password are provided, have their AppxManifest Publisher attribute 

.PARAMETER appxfilename
    OPTIONAL: The absolute path to the APPX package to be optimized. 
    If no path is supplied then a browse window will appear, select the target APPX and click Open to acquire its path.

.PARAMETER outputfolder

    OPTIONAL: The absolute path to the optimized APPX package to be distributed. 
    - It will also be used for the location of the temporary folder for compilation resuts.
    - If no path is supplied then the out put folder will be "C:\temp\APPXOutput" + APPX name + "\"

.PARAMETER inputfolder
    OPTIONAL: The absolute path to the temporary folder to which the files of the target APPX file will be extracted. 
    - If no path is supplied then the out put folder will be "C:\temp\APPXInput" + APPX name + 

.PARAMETER certpath
    OPTIONAL: The absolute path to the .pfx file used for sigining the APPX. 
    - Both cert file and password are required for package signature to be carried out.

.PARAMETER password
    OPTIONAL: Password for the .pfx file used for sigining the APPX. 
    - Both cert file and password are required for package signature to be carried out.

.PARAMETER silent
    OPTIONAL: '-silent yes' in the command line will suppress screen output.


.EXAMPLES (All parameters are optional)


> BuildMDILAPPX.ps1 
    
    You will be prompted to select an app package to optimize. Defaults (defined in optional input parameter 
    initialization) are:
    -	Working locations of the script are in c:\temp using  folders ...\APPXInput and ...\APPXOutput
    -	App package files are extracted to a subfolder of the \APPXInput folder bearing the name of the app
    -	Compilation output will be in a subfolder of the \APPXoutput folder bearing the app name
    -	The Repacked package of the optimized app will be output to a subfolder of the \APPXoutput folder 
        bearing the app name with “_optimized” appended
        -	If -pfxfilename and -password are provided then they will be used to sign the APPX package in this folder.
        -	Log files are also written to this folder.


> BuildMDILAPPX.ps1 –silent yes -mailkeypath "C:\cert folder\mailkey.aetx"


    Same as BuildMDILAPPX.ps1, but no prompts or status written to the screen  and a draft Outlook mail with the optimized XAP and associated .aetx file for email installation attached.


> BuildMDILAPPX.ps1 –appxfilename “c:\app packages folder\apppackage.appx” –inputfolder “c:\temp\input folder” –outputfolder “c:\temp\output folder” –pfxfilename “C:\cert folder\certfile.pfx” –password “cert_password_string”

    The package at the path –appxfilename will be: 
    -	Expanded to a subfolder of the –inputfolder folder bearing the name of the app
    -	Compiled and copied to a subfolder of the -outputfolder folder bearing the app name
    -	Repacked to a subfolder of the -outputfolder folder bearing the app name with “_optimized” appended. 
        -	Log files are also written to this folder.
        -   Package in that folder will be signed with the cert pointed to by –pfxfilename with the -password value.


#>


param(
       [parameter(Mandatory=$false)]
       [string]
       #appxfile to do the optimization
       $appxfilename,
       [parameter(Mandatory=$false)]
       [string]
       #optional pfx file for signing
       $pfxfilename=$null,
       [parameter(Mandatory=$false)]
       [string]
       #optional password for signing 
       $password=$null, 
       [parameter(Mandatory=$false)]
       [string]
       #optional inputfolder
       $inputfolder="C:\temp\APPXInput",
       [parameter(Mandatory=$false)]
       [string]
       #optional outputfolder
       $outputfolder="C:\temp\APPXOutput",
       [parameter(Mandatory=$false)]
       [string]
       #optional verbose flag
       $silent=$null,
       [string]
       #optional flag to send XAP and aetx at path specified by the value of this parameter in mail 
       $mailkeypath=$null
     ) 


#------------------------------------------------------------------------------#
##### INITIALIZATION ##########################################################
#------------------------------------------------------------------------------#

Function Get-FileName() 
{   
 [System.Reflection.Assembly]::LoadWithPartialName("System.windows.forms") |
 Out-Null

 $OpenFileDialog = New-Object System.Windows.Forms.OpenFileDialog
# $OpenFileDialog.initialDirectory = $initialDirectory
 $OpenFileDialog.filter = "All files (*.*)| *.*"
 $OpenFileDialog.ShowDialog() | Out-Null
 $OpenFileDialog.FileName
}


#----- _HostWriter -------------------------------------------------------------#
# 
# Write status comments to the build log and, if not silent, the screen.
#
#---------------------------------------------------------------------#
function _HostWriter($writetoscreen, $color, $logwrite)
{
    If ($logwrite -eq $null)
    {
        If(($color -eq '') -or ($color -eq $null)) {$color = " White";  Write-Host `n} 
        If($silent -ne "yes") { Write-Host $writetoscreen -ForegroundColor $color}
    }
    Write-Output . "> $writetoscreen -  $logwrite" | Out-File -FilePath $Buildlog -Append
}



    #If no $appxfilename provided then open file choose dialog
    if (($appxfilename -eq "") -or ($appxfilename -eq $null)) 
    {
        $appxfilename = Get-FileName 
        if (($appxfilename -eq $null) -or ($appxfilename -eq "")) {Write-Host "User Cancelled." -BackgroundColor "Red"; exit}
    }
    else 
    {
        #check the file existence
        $FileExists = Test-Path -path $appxfilename
        if($FileExists -ne $true)
        {
            _HostWriter -w  "$appxfilename file could not be found. Check the path and retry." -c "Red"
            exit
        }
    }

     
#----- PATHS -----------------------------------------------------------------#

#System Environment Variables
    $ProgramFilesx86 = (Get-Item "Env:ProgramFiles(x86)").value

#Tool paths
    $APPXMDILCompilePath = "$ProgramFilesx86\Microsoft SDKs\WindowsPhoneApp\v8.1\Tools\MDILXAPCompile"
    $MakeAppxPath = "$ProgramFilesx86\Windows Kits\8.1\bin\x64"

#Test working paths

    $FileNameAndExtension = Split-Path $appxfilename -Leaf
    $foldername = [System.IO.Path]::GetFileNameWithoutExtension("$appxfilename")
    $extension = [System.IO.Path]::GetExtension("$appxfilename")

    $APPXInput = "$inputfolder\$foldername" 
    $AppxOutput = "$outputfolder\$foldername"
    $APPXOptimized = "$outputfolder\$foldername" + "_optimized"



#------------------------------------------------------------------------------#   
##### SCRIPT FUNCTIONS ##################################################
#------------------------------------------------------------------------------#   

#----- ProcessAPPXComponents --------------------------------------------------#
#
# Performs compilation of the appx being processed.
#
#---------------------------------------------------------------------#
function ProcessAPPXComponents ($bundlemainappx)
{
 
    if($bundlemainappx -ne $null)
    {
        $inparam = "$APPXInput\BundleAppx_in"
        $outparam = "$APPXInput\BundleAppx_out"
    }
    else
    {
        $inparam = "$APPXInput"
        $outparam = "$APPXOutput"
    }

   #Create Logfile
    $LogFile = "$APPXOptimized\MDILLog_$FileNameAndExtension.txt"

    $executable = "$($APPXMDILCompilePath)\MDILXAPCompile.exe"

        $Arguments = ' /in:"' + $inparam + '"'
        $Arguments += ' /out:"' + $outparam + '"'
        $Arguments += ' /log:"' + $LogFile + '"'
        $Arguments += ' /config:"' + $APPXMDILCompilePath +'\MDILXAPCompileInput.xml' + '"'
        $Arguments += ' /appx'
        _HostWriter -logwrite "$executable $Arguments"
 
    $result = Start-Process -FilePath $executable -ArgumentList $Arguments -PassThru -Wait 

    if (($result.ExitCode -ne 0) -and ($result.ExitCode -ne 1000))
    {
         $exitcode = $result.ExitCode
       _HostWriter -w  "MDILXAPCompile failed for $APPXInput with error:(" $exitCode "). See $LogFile for details" -c "Red"
       _HostWriter -w  "EXITING SCRIPT" -c "Red"
       exit
    }
    else
    {
        _HostWriter -w  "MDILXAPCompile successfully compiled $APPXInput to $APPXOutput." -c "Green"    
        
    }
 
    CheckMDILLogforErrors $LogFile
 }



#------CheckMDILLogforErrors--------------------------------------------------#   
#
# Parses optimizer tool log files for Crossgen compiler errors not typically surfaced to the tool
#
#---------------------------------------------------------------------#
function CheckMDILLogforErrors ($logtocheck)
{
    If(Select-String -path $logtocheck -pattern "Error processing assembly")
    {
        _HostWriter -w "Optimization has failed. See $logtocheck for details."

        If ($silent -ne "yes") 
        {
            $a = new-object -comobject wscript.shell 
            $intAnswer = $a.popup("There was a problem optimizing this package. This script will exit.  Do you want to open the log to check for errors?", ` 
            0,"Delete Files",4) 
            If ($intAnswer -eq 6) 
            {
                #Open MDIL log
                explorer $logtocheck
            }
        }
        
        exit
    }
}


#----- UnpackAppx -------------------------------------------------------------#
#
# Unpacks an Appx 
#
#---------------------------------------------------------------------#
function UnpackAppx ($bundleAppxToUnpack)
{

    If ($bundleAppxToUnpack -ne $null) 
    {
        #Unpack bundle main appx file, ignore resource warnings
        $Arguments = "unpack /p `"$bundleAppxToUnpack`" /d `"$APPXInput\BundleAppx_in`" /l" 
        $IsBundle = $false
    } 
    Else
    {
        #Create temprory folder for extracted app package files
        _HostWriter -logwrite "Creating -APPXInput Directory $APPXInput"
        IF(Test-path $APPXInput){Remove-Item $APPXInput -Force -Recurse}
        New-Item $APPXInput -ItemType Directory -Force | Out-Null
 
        #Determine MakeAppx command based on file extension of appx, ignore resource warnings
        If($extension -eq ".appx") {$Arguments = "unpack /p `"$appxfilename`" /d `"$APPXInput`" /l"; $IsBundle = $false} 
        Elseif ($extension -eq ".appxbundle") {$Arguments = "unbundle /p `"$appxfilename`" /d `"$APPXInput`""; $IsBundle = $true}
        Else {_HostWriter -writetoscreen "Cannot unpack appx - extension `"$extension`" is not supported."}

    }


    $executable = "`"$MakeAppxPath\MakeAppx.exe`""
    _HostWriter -logwrite "$executable $Arguments"

    $result = Start-Process -FilePath $executable -ArgumentList "$Arguments" -NoNewWindow -PassThru -Wait -RedirectStandardOutput "$APPXOptimized\MakeAppxdlog.txt"
    if ($result.ExitCode -ne 0)
    {
        $exitcode = $result.ExitCode
        _HostWriter -w  "MakeAppx failed to extract $appxfilename to $APPXInput with error:($exitcode). See $outputfolder\MakeAppxdlog.txt for details. " -c "Red" 
       breakt 
   }
    else
    {
        _HostWriter -w  "MakeAppx successfully extracted $appxfilename to $APPXInput. " -c "Green"    
        
        # Unpack bundle child appxs
        if ($IsBundle){ProcessBundleAppx}
    }
}


#----- RepackAppx -------------------------------------------------------------#
#
# Repacks Appx packages.
# Optional param: $BundleMainAppx - folder containing the main APPX of the bundled package
#
#---------------------------------------------------------------------#
function RepackAppx ($BundleAppx)
{
    
    $executable = "`"$MakeAppxPath\MakeAppx.exe`""

    If ($BundleAppx -ne $null) 
        {
            #Delete original, pre-processed main appx of the bundle with optimized version
            _HostWriter -logwrite "Deleting original version of the bundle's main appx"
            IF(Test-path "$APPXInput\$BundleAppx"){Remove-Item "$APPXInput\$BundleAppx" -Force}
 
            #repack bundled appx child appxs
            $Arguments = "pack /d `"$APPXInput\BundleAppx_out`" /p `"$APPXInput\$BundleAppx`" /l"
        } 
    Elseif ($extension -eq ".appxbundle") 
        {
            #If repacking bundle then pack from Input folder to optimized 
	    # (optimization is performed on main package contained in the bundle)
            $Arguments = "bundle /d `"$APPXInput`" /p `"$APPXOptimized\$FileNameAndExtension`""
        }
    ElseIf($extension -eq ".appx") 
        {
             #repack fat pack appxs
             $Arguments = "pack /d `"$APPXOutput`" /p `"$APPXOptimized\$FileNameAndExtension`" /l"
        } 
    Else {_HostWriter -writetoscreen "Cannot re-pack appx - extension `"$extension`" is not supported."}

    $result = Start-Process -FilePath $executable -ArgumentList $Arguments -NoNewWindow -PassThru -Wait -RedirectStandardOutput "$APPXOptimized\MakeAppxdlog.txt"
    if ($result.ExitCode -ne 0)
    {
        $ec = $result.ExitCode
        _HostWriter -writetoscreen  "MakeAppx failed to repack $APPXInput with error:($ec)" -c "Red"
    }
    else
    {
        _HostWriter -writetoscreen  "MakeAppx successfully repacked $APPXInput to $APPXOptimized. See $APPXOptimized\MDILLog.txt for details" -c "Green"
    }
}
    

#----- ProcessBundleAppx ----------------------------------------------------------#
#
# Unpack, optimize and repack main appx packages of bundled appx packages.
#
#---------------------------------------------------------------------#
function ProcessBundleAppx
{

    #Parse AppxBundleManifest.xml for appx packages in the bundle 
    [xml]$xml = get-content "$APPXInput\AppxMetadata\AppxBundleManifest.xml"
    $manifestFiles = $xml.Bundle.Packages.Package

    Foreach($Package in $manifestFiles) 
    {
        $appxName = $Package.FileName
        
        #Create temporary processing folders to process bundle's appx packages
        $package_in =  New-Item -ItemType directory -Path "$APPXInput\BundleAppx_in" -force
        $package_out =  New-Item -ItemType directory -Path "$APPXInput\BundleAppx_out" -force

        #Unpack 
            _HostWriter -writetoscreen "Extract $appxName to temprorary folder ..."
        UnpackAppx "$APPXInput\$appxName"

        #Optimize Main Appx
        If ($Package.Type -eq "application")
        {        
                _HostWriter -writetoscreen "Optimize Main Appx ($appxName) ..."
            ProcessAppxComponents "$package_in"
        }
        else 
        {
            move-item "$package_in/*" "$package_out"
        }

        #Fix Publisher name
            _HostWriter -writetoscreen "Ensure $appxName Publisher and signing cert subject match ..."
        if($doSign){MatchCertAndAppxPublisher "$package_out"}

        #Repack
                _HostWriter -writetoscreen "Repack Main Appx to appxbundle and remove temporary folders ..."
        RepackAppx "$appxName" 
    
        # Discard temporary folders
        Remove-Item "$package_in" -Force -Recurse
        Remove-Item "$package_out" -Force -Recurse
    }

}



#----- SignAppx ----------------------------------------------------------#
#
# Signs Appx packages if path to signing -certpath and -password are provided as script input parameters.
#
#---------------------------------------------------------------------#
function SignAppx 
{

    $AppxToSign = "$APPXOptimized\$FileNameAndExtension"
    $executable = "$MakeAppxPath\Signtool.exe"

    $Arguments += ' sign'
    $Arguments += ' /fd "SHA256" /a'
    $Arguments += ' /f "' + $pfxfilename  + '"'
    $Arguments += ' /p "' + $password  + '"'
    $Arguments += ' "' + $AppxToSign + '"'

    $APPXsigntoollog = "$APPXOptimized\SignToolLog_$FileNameAndExtension.txt"
    _HostWriter -logwrite "$executable $Arguments"

    $result = Start-Process -FilePath $executable -ArgumentList $Arguments -PassThru -Wait   
    if ($result.ExitCode -ne 0)
    {
        _HostWriter -w  "SignTool failed for $signtarget with error:(" $result.ExitCode ")" -c "Red"
    }
    else
    {
        _HostWriter -w  "SignTool successfully signed $APPXInput to $APPXOptimized. See $APPXOptimized\MDILLog.txt for details" -c "Green"

        
    }

}



#----- MatchCertAndAppxPublisher ----------------------------------------------#
#
# Overwrite the /Package/Identity Publisher attribute of the AppxManifest.xml with the Subject Name
# of the cert being used to sign the Appx.
# 
#---------------------------------------------------------------------#
function MatchCertAndAppxPublisher ($targetfolder)
{
        _HostWriter -logwrite "  filepath $pfxfilename"
    $cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2
    $cert.Import("$pfxfilename",$password,'DefaultKeySet')
    $pfxsubjectname = $cert.Subject.ToString()

    If (($targetfolder -like "*BundleAppx*") -or ($extension -eq ".appx")) {$appxmanifestpath = "$targetfolder\AppxManifest.xml"; $node = "Package"; }
  
    ElseIf ($extension -eq ".appxbundle") {$appxmanifestpath = "$APPXInput\AppxMetadata\AppxBundleManifest.xml"; $node = "Bundle" }
  
  
    [xml]$Manifestxml = [xml](Get-Content "$appxmanifestpath" )

    $Manifestxml.$node.Identity.SetAttribute("Publisher", "$pfxsubjectname")
    $Manifestxml.Save("$appxmanifestpath")

}


#-----  Send Mail -------------------------------------------------------------#
# 
# Creates and activates a draft Outlook mail with the optimized XAP and .AETX file specified in 
# optional -mailkeypath commandline parameter (hopefully in the foreground, but depnds on context).
#
#---------------------------------------------------------------------#
function SendMail
{
    If(($mailkeypath -ne $null) -and ($mailkeypath -ne ''))
    {
        If(Test-Path $mailkeypath)
        {

            $ol = New-Object -comObject Outlook.Application 
            
            Sleep 1 #Outlook takes a bit of time to create the new object
             
            $mail = $ol.CreateItem(0)
            $mail.Subject = "$FileNameAndExtension"
            $mail.Attachments.Add("$APPXOptimized\$FileNameAndExtension") | Out-Null
            $mail.Attachments.Add("$mailkeypath") | Out-Null
            $mail.save()

            $inspector = $mail.GetInspector
            $inspector.Activate()
            _HostWriter -writetoscreen "Mail was created with $FileNameAndExtension and $mailkeypath attached." -color Green
       } 
       else {_HostWriter -writetoscreen "Mail not created. Could not find $mailkeypath." -color Red}
    } 
    else {_HostWriter -writetoscreen "Mail not created. No -mailkeypath provided." -color Green}

}
    



#------------------------------------------------------------------------------#
##### ENTRY POINT ##############################################################
#------------------------------------------------------------------------------#

    $doSign = (($pfxfilename -ne "") -and ($password -ne ""))
 
    #Make the final outputfolder
    If(Test-path $APPXOptimized) {Remove-Item $APPXOptimized -Force -recurse -ErrorAction Inquire}
    New-Item $APPXOptimized -ItemType Directory -Force | Out-Null

    #Create and initialize log file
    $Buildlog = "$APPXOptimized\BuildLog_$FileNameAndExtension.txt"
    $datenow = Get-date
    _HostWriter -writetoscreen ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" -color green 
    _HostWriter  -logwrite "$FileNameAndExtension Optimization Log - $datenow ------------->" 


    #Create compile output folder
        _HostWriter -logwrite "Creating -APPXOutput Directory $APPXOutput"
    If(Test-path $APPXOutput) {Remove-Item $APPXOutput -Force -recurse}
    New-Item $APPXOutput -ItemType Directory -Force  | Out-Null
    

        _HostWriter -writetoscreen "UnPack the Appx "
    UnpackAppx

    If($extension -ne ".appxbundle") 
    {        _HostWriter -writetoscreen "Optimize the Appx"
        ProcessAPPXComponents

            _HostWriter -writetoscreen "Ensure AppxManifest and signing cert Publisher names match ..."
        if($doSign){MatchCertAndAppxPublisher $AppxOutput}
    }
    else
    {
            _HostWriter -writetoscreen "Ensure AppxBundleManifest and signing cert Publisher names match ..."
        if($doSign){MatchCertAndAppxPublisher $AppxInput}
    }

        _HostWriter -writetoscreen "Repack the Appx "
    RepackAppx

    #Sign APPX if cert and password are provided
    if($doSign)
    {
            _HostWriter -writetoscreen "Sign the optimized app package " 
        SignAppx # "$APPXOptimized\$FileNameAndExtension"
    }
    else
    {
           _HostWriter -writetoscreen "Package not signed: no -pfxfilename and/or -password supplied." 
    }     


#------ Cleanup ------------------------------------------------------------------------#

    If ($silent -ne "yes") 
    {
        $a = new-object -comobject wscript.shell 
        $intAnswer = $a.popup("Do you want to delete the input and output folders for this app package?", ` 
        0,"Delete Files",4) 
        If ($intAnswer -eq 6) {$removeFolders = "yes"} else {$removeFolders = "no"}
                    
        #Open Output folder
        explorer $APPXOptimized
    }
    else
    {
        $removeFolders = "yes"
    }

    If($removeFolders -eq "yes") 
    {
        Remove-Item "$APPXInput" -Recurse -Force
            _HostWriter -w "    Folder deleted: $APPXInput" -c "Cyan" 
        Remove-Item "$APPXOutput" -Recurse -Force
            _HostWriter -w "    Folder deleted: $APPXOutput" -c "Cyan" 
    }

    SendMail