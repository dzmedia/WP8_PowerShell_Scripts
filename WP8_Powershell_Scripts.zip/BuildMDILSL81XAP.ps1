﻿<#

.SYNOPSIS
BuildMDILSL81XAP.ps1 optimizes SL 8.1 XAP packages allowing them to launch without JIT compilation.

.DESCRIPTION
    None yet.

.PARAMETER xapfilename
    OPTIONAL: The absolute path to the XAP package to be optimized. 
    - If no path is supplied then a browse window will appear, select the target SL 8.1 XAP and click Open to acquire its path.

.PARAMETER outputfolder
    OPTIONAL: The absolute path to the desired location of the optimized XAP package output by this script. 
    - It will also be used for the location of the temporary folder for compilation resuts.
    - If no path is supplied then the out put folder will be "C:\temp\SL81XAPOutput" + XAP name + "\"

.PARAMETER inputfolder
    OPTIONAL: The absolute path to the temporary folder to which the files of the target XAP file will be extracted. 
    - If no path is supplied then the out put folder will be "C:\temp\SL81XAPInput" + XAP name 

.PARAMETER certpath
    OPTIONAL: The absolute path to the .pfx file used for sigining the SL 8.1 XAP. 
    - Both cert file and password are required for package signature to be carried out.

.PARAMETER password
    OPTIONAL: Password for the .pfx file used for sigining the SL 8.1 XAP. 
    - Both cert file and password are required for package signature to be carried out.

.PARAMETER silent
    OPTIONAL: '-silent yes' in the command line will suppress screen output.

.PARAMETER mailkeypath
    OPTIONAL: '-mailkeypath "c:\temp\mailkey.aetx"' providing path to .aetx file to allow email app distribution will cause a draft mail with attachments to be created.


.EXAMPLES (All parameters are optional)


> BuildMDILSL81XAP.ps1 
    
    You will be prompted to select an app package to optimize. Defaults (defined in optional input parameter 
    initialization) are:
    -	Working locations of the script are in c:\temp using  folders ...\SL81XAPInput and ...\SL81XAPOutput
    -	App package files are extracted to a subfolder of the \SL81XAPInput folder bearing the name of the app
    -	Compilation output will be in a subfolder of the \SL81XAPoutput folder bearing the app name
    -	The Repacked package of the optimized app will be output to a subfolder of the \SL81XAPoutput folder 
        bearing the app name with “_optimized” appended
        -	If -pfxfilename and -password are provided then they will be used to sign the SL81XAP package in this folder.
        -	Log files are also written to this folder.


> BuildMDILSL81XAP.ps1 –silent “yes” -mailkeypath "C:\cert folder\mailkey.aetx"

    Same as BuildMDILSL81XAP.ps1, but no prompts or status written to the screen and a draft Outlook mail with the optimized XAP and associated .aetx file for email installation attached.


> BuildMDILSL81XAP.ps1 –xapfilename “c:\app packages folder\apppackage.xap” –inputfolder “c:\temp\input folder” –outputfolder “c:\temp\output folder” –pfxfilename “C:\cert folder\certfile.pfx” –password “cert_password_string”

    The package at the path –xapfilename will be: 
    -	Expanded to a subfolder of the –inputfolder folder bearing the name of the app
    -	Compiled and copied to a subfolder of the -outputfolder folder bearing the app name
    -	Repacked to a subfolder of the -outputfolder folder bearing the app name with “_optimized” appended. 
        -	Log files are also written to this folder.
        -   Package in that folder will be signed with the cert pointed to by –pfxfilename with the -password value.


#>



param(
       [parameter(Mandatory=$false)]
       [string]
       #xapfile to do the optimization
       $xapfilename,
       [parameter(Mandatory=$false)]
       [string]
       #optional pfx file for signing        
       $pfxfilename =$null, 
       [parameter(Mandatory=$false)]
       [string]
       #optional password for signing
       $password=$null, 
       [parameter(Mandatory=$false)]
       [string]
       #optional inputfolder
       $inputfolder="C:\temp\SL81XAPInput",
       [parameter(Mandatory=$false)]
       [string]
       #optional outputfolder
       $outputfolder="C:\temp\SL81XAPOutput",
       [parameter(Mandatory=$false)]
       [string]
       #optional verbose flag
       $silent=$null,
       [string]
       #optional flag to send XAP and aetx at path specified by the value of this parameter in mail 
       $mailkeypath=$null
     )



#------------------------------------------------------------------------------#   
##### SCRIPT INITIALIZATION ##################################################
#------------------------------------------------------------------------------#   

#----- Get-FileName --------------------------------------------------#
#
# Displays Open File dialog to select APPX to optimize.
#
#---------------------------------------------------------------------#
Function Get-FileName
{   
     [System.Reflection.Assembly]::LoadWithPartialName("System.windows.forms") |
     Out-Null

     $OpenFileDialog = New-Object System.Windows.Forms.OpenFileDialog
     $OpenFileDialog.filter = "All files (*.*)| *.*"
     $OpenFileDialog.ShowDialog() | Out-Null
     $OpenFileDialog.FileName
}



#----- _HostWriter -------------------------------------------------------------#
# 
# Write status comments to the build log and, if not silent, the screen.
#
#---------------------------------------------------------------------#
function _HostWriter($writetoscreen, $color, $logwrite)
{
    If ($logwrite -eq $null)
    {
        If(($color -eq '') -or ($color -eq $null)) {$color = " White";  Write-Host `n} 
        If($silent -ne "yes") { Write-Host $writetoscreen -ForegroundColor $color}
    }
    Write-Output . "> $writetoscreen -  $logwrite" | Out-File -FilePath $Buildlog -Append
}


#----- INITIALIZE GLOBAL VARIABLES ------------------------------------#

    #If no $xapfile provided open file choose dialog
    if (($xapfilename -eq "") -or ($xapfilename -eq $null))
    {
        $xapfilename = Get-FileName
        if ($xapfilename -eq "") {_HostWriter -w  "User Cancelled." -c "Red"; exit}
    }
    else 
    {
        #check the file existence at user supplied path
        $FileExists = Test-Path -path $xapfilename
        if($FileExists -ne $true)
        {
            Write-Host $xapfilename " file could not be found. Check the path and retry." -ForegroundColor Red
            exit
        }
    }

     
#----- PATHS -----------------------------------------------------------#
    #System Environment Variables
    $ProgramFilesx86 = (Get-Item "Env:ProgramFiles(x86)").value

    #Tool paths
    $APPXMDILCompilePath = "$ProgramFilesx86\Microsoft SDKs\WindowsPhoneApp\v8.1\Tools\MDILXAPCompile"
    $SL81XAPMDILCompilePath = "$ProgramFilesx86\Microsoft SDKs\Windows Phone\v8.1\Tools\MDILXAPCompile"
    $SignToolPath = "$ProgramFilesx86\Windows Kits\8.1\bin\x64"
    
    #Working paths and variables
    
    $FileNameAndExtension = $xapfilename.split(“\”); 
    $FileNameAndExtension = $FileNameAndExtension[$FileNameAndExtension.Count -1]
    
    $foldername=$FileNameAndExtension.TrimEnd(".xap"); 

    $SL81XAPInput = "$inputfolder\$Foldername"
    $SL81XAPOutput = "$outputfolder\$Foldername"
    $SL81XAPOptimized = "$outputfolder\$foldername" + "_optimized"
    $ProjectFileName = "$SL81XAPInput\MDILProjectFiles.xml"

    $doSign = (($pfxfilename -ne "") -and ($password -ne ""))

    #Make the final outputfolder
    If(Test-path $SL81XAPOptimized) {Remove-Item $SL81XAPOptimized -Force -recurse -ErrorAction Inquire}
    New-Item $SL81XAPOptimized -ItemType Directory -Force

    #Create and initialize log file
    $Buildlog = "$SL81XAPOptimized\BuildLog_$FileNameAndExtension.txt"
    $datenow = Get-date
    Write-Output "$FileNameAndExtension Optimization Log - $datenow " "------------->"  | Out-File -FilePath $Buildlog -Append

    #Create output and compile folders
        _HostWriter -logwrite "Creating -APPXOutput Directory $APPXOutput"
    If(Test-path $SL81XAPOutput) {Remove-Item $SL81XAPOutput -Force -recurse}
    New-Item $SL81XAPOutput -ItemType Directory -Force
    



#------------------------------------------------------------------------------#   
##### SCRIPT FUNCTIONS ##################################################
#------------------------------------------------------------------------------#   

#----ProcessXAPComponents-------------------------------------------------------#   
#
# Optimizes XAP components of a SL8.1 XAP.
# Param: $CFParams - Semicolon delimited lists of appx component file names used for the CompileFilter command of the compiler
#
#---------------------------------------------------------------------#
function ProcessXAPComponents ($CFparams)
{

    $LogFile = "$SL81XAPOptimized\MDILLogXAP_$FileNameAndExtension.txt"

    $executable = "$($SL81XAPMDILCompilePath)\MDILXAPCompile.exe"

        $Arguments += ' /in:"' + $SL81XAPInput + '"'
        $Arguments += ' /out:"' + $SL81XAPOutput + '"'
        $Arguments += ' /log:"' + $LogFile + '"'
        $Arguments += ' /config:"' + $SL81XAPMDILCompilePath + '\MDILXAPCompileInput.xml' + '"'
        $Arguments += ' /compilefilter:"' + $CFparams + '"'
        $Arguments += ' /appx'
        _HostWriter -logwrite "$executable $Arguments"

    #If the file is already Tritonized remove the existing MDILFilesListXAP.xml before calling MDILXapCompile.e
    _HostWriter -logwrite "Overwriting $SL81XAPInput/MDILFileListXAP.xml if it exists"
    IF(Test-path $SL81XAPInput/MDILFileListXAP.xml){Remove-Item "$SL81XAPInput/MDILFileListXAP.xml" -Force -Recurse}

   $result = Start-Process -FilePath $executable -ArgumentList $Arguments -PassThru -wait 
    if (($result.ExitCode -ne 0) -and ($result.ExitCode -ne 1000))       # Exit code 1000 is the successful result when no managed assemblies exist in the app package
    {
        _HostWriter -writetoscreen "MDILXAPCompile failed for XAP components in $SL81XAPInput with error:(" $result.ExitCode.ToString() "). See $LogFile for details."  -color "Red"
        exit
    }
    else
    {
        _HostWriter -writetoscreen "MDILXAPCompile successfully compiled XAP components in $SL81XAPInput to $SL81XAPOutput. " -color "Green"
        
        #Make MDILFileList framework-specific
        Rename-Item $SL81XapOutput\MDILFileList.xml MDILFileListXAP.xml
        CheckMDILLogforErrors $LogFile

    }
}



#------ProcessAPPXComponents---------------------------------------------------#   
#
# Optimizes Appx components of a SL8.1 XAP.
# Param: $CFParams - Semicolon delimited lists of appx component file names used for the CompileFilter command of the compiler
#
#---------------------------------------------------------------------#
function ProcessAPPXComponents  ($CFparams)
{
 
   #Create Logfile
    $LogFile = "$SL81XAPOptimized\MDILLogAppx_$FileNameAndExtension.txt"
 
    $executable = '"' + $($APPXMDILCompilePath) + '\MDILXAPCompile.exe"'

        $Arguments += '/in:"' + $SL81XAPInput + '"'
        $Arguments += ' /out:"' + $SL81XapOutput + '"'
        $Arguments += ' /log:"' + $LogFile + '"'
        $Arguments += ' /config:"' + $APPXMDILCompilePath +'\MDILXAPCompileInput.xml' + '"'
        $Arguments += ' /compilefilter:"' +  $CFparams + '"'
        $Arguments += ' /appx'
        _HostWriter -logwrite "$executable $Arguments"

    #If the file is already Tritonized remove the existing MDILFilesListAPPX.xml before calling MDILXapCompile.e
    _HostWriter -logwrite "Overwriting $SL81XAPInput/MDILFileListXAP.xml if it exists"
    IF(Test-path $SL81XAPInput/MDILFileListAPPX.xml){Remove-Item "$SL81XAPInput/MDILFileListAPPX.xml" -Force -Recurse}

    $result = Start-Process -FilePath $executable -ArgumentList $Arguments -PassThru -wait 

    if (($result.ExitCode -ne 0) -and ($result.ExitCode -ne 1000))       # Exit code 1000 is the successful result when no managed assemblies exist in the app package
    {
        _HostWriter -writetoscreen "MDILXAPCompile failed for APPX components in $SL81XAPInput with error:(" $result.ExitCode "). See $LogFile for details." -color "Red"
        exit
    }
    else
    {
        _HostWriter -writetoscreen "MDILXAPCompile successfully compiled APPX componenet in $SL81XAPInput to $SL81XAPOutput." -color "Green"    
       
        Rename-Item $SL81XapOutput\MDILFileList.xml MDILFileListAPPX.xml
        CheckMDILLogforErrors $LogFile
    }
}



#------CheckMDILLogforErrors--------------------------------------------------#   
#
# Parses optimizer tool log files for Crossgen compiler errors not typically surfaced to the tool
#
#---------------------------------------------------------------------#
function CheckMDILLogforErrors ($logtocheck)
{
    If(Select-String -path $logtocheck -pattern "Error processing assembly")
    {
        _Hostwriter -w "Optimization has failed. See $logtocheck for details."

        If ($silent -ne "yes") 
        {
            $a = new-object -comobject wscript.shell 
            $intAnswer = $a.popup("There was a problem optimizing this package. This script will exit.  Do you want to open the log to check for errors?", ` 
            0,"Delete Files",4) 
            If ($intAnswer -eq 6) 
            {
                #Open MDIL log
                explorer $logtocheck
            }
        }
        
        exit
    }
}




#------SignAllPackageFiles-----------------------------------------------------------------#   
#
# Signs files within SL8.1 packages.
# Param: $filetosign - optional: used when signing package files - if $null sign the whole package
#
#---------------------------------------------------------------------#
function SignAllPackageFiles
{
    $packagefilelist = Get-ChildItem $SL81XAPOutput -rec -include *.dll,*.winmd, *.exe | Where-object {!$_.psIsContainer -eq $true} | ForEach-Object -Process {$_.FullName}
    Foreach($cn in $packagefilelist){SignXAP $cn}
}



#------SignXAP-----------------------------------------------------------------#   
#
# Signs SL8.1 packages.
# Param: $filetosign - optional: used when signing package files - if $null sign the whole package
#
#---------------------------------------------------------------------#
function SignXAP ($filetosign)
{
    
    If ($filetosign -eq $null) 
    {
        $signingtarget = "`"$SL81XAPOptimized\$FileNameAndExtension`""
    }
    else
    {
        $signingtarget = $filetosign
    }

    $executable = "`"$SignToolPath\Signtool.exe`""
    $signtoollog =  "$SL81XAPOptimized\SigntoolOutput_$FileNameAndExtension.log"

    $Arguments += ' sign'
    $Arguments += ' /v'
    $Arguments += ' /fd SHA256' 
    $Arguments += ' /f "' + $pfxfilename  + '"'
    $Arguments += ' /p "' + $password  + '"'
    $Arguments += ' "' + $signingtarget + '"'
     _HostWriter -logwrite "$executable $Arguments"

    
     $result = Start-Process -FilePath $executable -ArgumentList $Arguments -NoNewWindow -PassThru -wait -RedirectStandardOutput $signtoollog
    if ($result.ExitCode -ne 0)
    {
        _HostWriter -writetoscreen "SignTool failed for $signingtarget with error:(" $result.ExitCode ") See $signtoollog for details." -color "Red"
    }
    else
    {
        _HostWriter -writetoscreen "SignTool successfully signed $signingtarget. See $signtoollog for details." -color "Green"    
        
    }

}


#------CompileBothPhases-------------------------------------------------------#   
#
# generates $XAPCompileFilterParameter and $APPXCompileFilterParameter for use in MDILXAPCompile calls for optimizing SL 8.1 Applications.
# Param: $ProjectFileName
#
#---------------------------------------------------------------------#
Function CompileBothPhases 
{

    #check the existence of MDILProjectsFile.xml
     $FileExists = Test-Path -path $Projectfilename
     if($FileExists -ne $true)
     {
        _HostWriter -writetoscreen "NO $Projectfilename FILE COULD NOT BE FOUND IN THIS APP PACKAGE ..."  -color "Red"
     }

    # Parse framework file lists from MDILProjectFiles.xml
    [xml]$xml11 = get-content $Projectfilename
    
    
    #PHASE 1: XAP COMPONENTS
    #--------------------------------------------#   
    $XAPxml = $xml11.Files.XAPFiles  
    $XAPPCL =  $XAPxml.SelectNodes("/Files/XAPFiles/File[@Type='PCL']")

        _HostWriter -writetoscreen  "Create XAP CompileFilterParameter"
    Foreach ($cn in $XAPXML.Childnodes) {$cn.InnerText += ";"}
    $XAPparam = $XAPxml.innertext.TrimEnd(";") 

        _HostWriter -writetoscreen  "Process XAP components "
    ProcessXAPComponents $XAPparam
     
     _HostWriter -logwrite "XAP COMPILEFILTER: $XAPparam"


    #PHASE 2: APPX COMPONENTS
    #--------------------------------------------#   
    $APPXxml = $xml11.Files.APPXFiles
    
    Try
    {
        # Remove Duplicate PCLs from XAPFile Node to avoid double binding upon install on a device 
        $APPXPCL =  $APPXxml.SelectNodes("/Files/APPXFiles/File[@Type='PCL']")
        ForEach($XAPFile in $XAPPCL) 
        {
            ForEach($APPXFile in $APPXPCL) { If($APPXFile.InnerText -eq $XAPFile.InnerText) {$XAPFile.ParentNode.RemoveChild($XAPFile)}}
        }
        
            _HostWriter -writetoscreen  "Create APPX CompileFilterParameter"
        Foreach ($cn in $APPXXML.Childnodes) {$cn.InnerText += ";"}
        $APPXparam = $APPXxml.innertext.TrimEnd(";") 
         
            _HostWriter -writetoscreen "Process APPX components " 
        ProcessAPPXComponents $APPXparam
            _HostWriter -logwrite "APPX COMPILEFILTER: $APPXparam"

    }
    Catch
    {
        #if no APPX Components generate an empty MDILFileListAPPX.xml
            _HostWriter -writetoscreen "NO APPX ASSEMBLIES FOUND IN THIS SL 8.1 XAP" -color "Yellow"
    }

} #end of CompileBothPhases function


#------UnZipFile----------------------------------------------------------------#   
#
# unzip the contents to a specific destination folder.
# Param: $zipfilename - file to be un-zipped
# Param: $destination - location to extract $ZipFileName to 
#
#---------------------------------------------------------------------#
function UnZipFile
{
param($zipfilename,$destination)

    If(Test-path $destination) {Remove-Item $destination -Force -recurse}
    Try 
    {
        [System.Reflection.Assembly]::Load("System.IO.Compression.FileSystem,Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089") | Out-Null
        [System.IO.Compression.ZipFile]::ExtractToDirectory($zipfilename,$destination)
    } 
    Catch {_HostWriter -writetoscreen "Could not unzip $zipfilename to $destination." -color "red"; exit} 
    
    _HostWriter -writetoscreen "$zipfilename successfully unzipped to $destination." -color "green"

} #end of UnZipFile function


#-----CreateXap------------------------------------------------------------------#   
#
# Rezip the optimized, signed xap file to the output folder.
# 
#---------------------------------------------------------------------#
function CreateXap
{
    [System.IO.Compression.ZipFile]::CreateFromDirectory($SL81XAPOutput, "$SL81XAPOptimized\$FileNameAndExtension")
    _HostWriter -writetoscreen "$FileNameAndExtension successfully rezipped to $SL81XAPOptimized." -color "green"

}


#-----  Send Mail -------------------------------------------------------------#
# 
# Creates and activates a draft Outlook mail with the optimized XAP and .AETX file specified in 
# optional -mailkeypath commandline parameter (hopefully in the foreground, but depnds on context).
#
#---------------------------------------------------------------------#
function SendMail
{
    If(($mailkeypath -ne $null) -and ($mailkeypath -ne ''))
    {
        If(Test-Path $mailkeypath)
        {

            $ol = New-Object -comObject Outlook.Application 
            
            Sleep 1 #Outlook takes a bit of time to create the new object
             
            $mail = $ol.CreateItem(0)
            $mail.Subject = "$FileNameAndExtension"
            $mail.Attachments.Add("$SL81XAPOptimized\$FileNameAndExtension") | Out-Null
            $mail.Attachments.Add("$mailkeypath") | Out-Null
            $mail.save()

            $inspector = $mail.GetInspector
            $inspector.Activate()
            _HostWriter -writetoscreen "Mail was created with $FileNameAndExtension and $mailkeypath attached." -color Green
       } 
       else {_HostWriter -writetoscreen "Mail not created. Could not find $mailkeypath." -color Red}
    } 
    else {_HostWriter -writetoscreen "Mail not created. No -mailkeypath provided." -color Green}

}
    

#------------------------------------------------------------------------------#   
###### ENTRY POINT ###########################################################
#------------------------------------------------------------------------------#   

    #Expand the XAP to the input folder
        _HostWriter -writetoscreen "UnZip the app package" 
    UnZipFile -zipfilename $xapfilename -destination $SL81XAPInput

    #Compile for each framework separately to the output folder
        _HostWriter -writetoscreen "Compile Both XAP and APPX Phases "
    CompileBothPhases

    #Sign all dlls and winmds in the XAP if cert and password are provided
    if ($doSign)
    {
            _HostWriter -writetoscreen "Sign all files within the XAP package"  
        SignAllPackageFiles
    }

    #Recompress the XAP to the optimized folder
        _HostWriter -writetoscreen "Re-Zip the XAP"  
     CreateXap 


    #Sign XAP if cert and password are provided
    if ($doSign)
    {
            _HostWriter -writetoscreen "Sign the optimized app package " 
        SignXap
    } 
    else
    {
           _HostWriter -writetoscreen "Package not signed (cert file and/or password not supplied)" 
    }     


    #Cleanup
    If ($silent -ne "yes") 
    {
        $a = new-object -comobject wscript.shell 
        $intAnswer = $a.popup("Do you want to delete the input and output folders for this app package?", ` 
        0,"Delete Files",4) 
        If ($intAnswer -eq 6) {$removeFolders = "yes"} else {$removeFolders = "no"}
                    
        #Open Output folder
        explorer $SL81XAPOptimized
    }
    else
    {
        $removeFolders = "yes"
    }

    If($removeFolders -eq "yes") 
    {
        Remove-Item $SL81XAPInput -Recurse
            _HostWriter -writetoscreen "    Folder deleted: $SL81XAPInput" -color "Red" 
        Remove-Item $SL81XAPOutput -Recurse
            _HostWriter -writetoscreen "    Folder deleted: $SL81XAPOutput" -color "Red" 
    }

    SendMail

